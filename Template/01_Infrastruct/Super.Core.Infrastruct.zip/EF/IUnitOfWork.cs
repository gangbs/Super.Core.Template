﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.EF
{
    public interface IUnitOfWork
    {
        SaveResult SaveChanges();
    }
}
