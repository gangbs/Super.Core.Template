﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Query2Exp
{
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = false)]
    public class IgnoreAttribute : Attribute
    {
    }
}
