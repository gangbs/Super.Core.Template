﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace $safeprojectname$.File
{
    public class FileUtility
    {
        public static void CreateCategoryIfNotExist(string category)
        {
            if (!Directory.Exists(category))
            {
                Directory.CreateDirectory(category);
            }
        }
    }
}
