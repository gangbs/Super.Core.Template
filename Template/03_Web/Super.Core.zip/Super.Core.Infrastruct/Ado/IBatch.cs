﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Ado
{
    public interface IBatch<T> 
    {
        string TableName { get; }
        DbConnection DbConn { get; }
        int BatchInsert(List<T> lstData);
        Task<int> BatchInsertAsync(List<T> lstData);
    }
}
